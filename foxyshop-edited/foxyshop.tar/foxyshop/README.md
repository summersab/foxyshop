FoxyShop
========

FoxyShop - WordPress plugin for FoxyCart

See readme.txt for complete info on this plugin
