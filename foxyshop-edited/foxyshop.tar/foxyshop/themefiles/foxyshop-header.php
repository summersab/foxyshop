<?php
//Put anything here that you want to be at the top of every FoxyShop-related template page
//This is very helpful for making your FoxyShop pages work with your template
//Place this file in your template theme folder



?>